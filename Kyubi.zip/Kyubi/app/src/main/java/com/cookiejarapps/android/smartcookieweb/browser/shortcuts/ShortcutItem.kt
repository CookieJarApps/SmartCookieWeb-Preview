package com.cookiejarapps.android.smartcookieweb.browser.shortcuts

import android.graphics.Bitmap

data class ShortcutItem(val icon: Bitmap, val url: String, val add: Boolean = false)
