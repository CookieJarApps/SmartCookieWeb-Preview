package com.cookiejarapps.android.smartcookieweb.settings

enum class ThemeChoice {
    LIGHT,
    DARK,
    SYSTEM
}