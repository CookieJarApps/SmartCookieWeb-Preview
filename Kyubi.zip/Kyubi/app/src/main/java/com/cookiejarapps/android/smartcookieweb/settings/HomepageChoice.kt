package com.cookiejarapps.android.smartcookieweb.settings

enum class HomepageChoice {
    VIEW,
    BLANK_PAGE,
    CUSTOM_PAGE
}