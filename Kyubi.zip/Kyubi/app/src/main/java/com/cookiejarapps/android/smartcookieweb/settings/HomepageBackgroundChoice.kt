package com.cookiejarapps.android.smartcookieweb.settings

enum class HomepageBackgroundChoice {
    NONE,
    GALLERY,
    URL
}