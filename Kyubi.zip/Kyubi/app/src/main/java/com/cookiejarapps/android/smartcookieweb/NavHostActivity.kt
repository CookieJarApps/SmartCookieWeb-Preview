package com.cookiejarapps.android.smartcookieweb

import androidx.appcompat.app.ActionBar

interface NavHostActivity {
    fun getSupportActionBarAndInflateIfNecessary(): ActionBar
}
