package com.cookiejarapps.android.smartcookieweb.browser

enum class AddonSortType {
    RATING,
    A_Z,
    Z_A
}